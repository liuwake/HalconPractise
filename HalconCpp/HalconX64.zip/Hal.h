using namespace std;
#include <string>

#ifndef HAL_H
#define HAL_H


string action(string path);

#endif

