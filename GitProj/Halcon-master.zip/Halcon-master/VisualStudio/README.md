## Visual Studio 与 Halcon
* [Visual Studio 10.0设置引用HalconDotNet.dll](https://blog.csdn.net/bitezijie/article/details/8858638)
* [VS2010的helplibrary问题](https://blog.csdn.net/bitezijie/article/details/8868643)
* [解决 Visual Studio Debugger Just-In-Time Debugging](https://blog.csdn.net/bitezijie/article/details/43937667)
* [解决Solid Converter PDF的缓存文件对C盘的占用](https://blog.csdn.net/bitezijie/article/details/43561813)
* [如何在Visual Studio 10.0中设置Halcon机器视觉](https://blog.csdn.net/bitezijie/article/details/24626731)
